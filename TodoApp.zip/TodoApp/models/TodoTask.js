const mongoose= require('mongoose');
const todoTaskSchema = new mongoose.Schema({
    content:{type: String,
        required: true
    },
    date:{type:Date,
        default: Date.now
    }
})
    module.experts = mongoose.model('TodoTask',todoTaskSchema);